#!/bin/sh
cd "$(dirname "$0")"
python3 autoclicker-1.1.py
