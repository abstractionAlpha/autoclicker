import time
from pynput import mouse

mousecontroller = mouse.Controller()

delay = 0.75  # in seconds

while True:
    mousecontroller.press(mouse.Button.left)
    mousecontroller.release(mouse.Button.left)
    time.sleep(0.75)
